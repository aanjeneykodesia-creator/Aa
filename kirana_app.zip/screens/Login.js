import React,{useState} from 'react';
import {View,Text,TextInput,Button} from 'react-native';

export default function Login({navigation}){
 const [mobile,setMobile]=useState('');
 return(
  <View style={{padding:20}}>
    <Text>Enter Mobile Number</Text>
    <TextInput value={mobile} onChangeText={setMobile} keyboardType="number-pad" style={{borderWidth:1,marginVertical:10}}/>
    <Button title="Continue" onPress={()=>navigation.navigate('Home')}/>
  </View>
 );
}
